package com.janocare.notification.api.responses;

public class ApiResponse<T> {

    public boolean success;

    public String message;

    public T data;

    public ApiResponse() {}

    public static <T> ApiResponse<T> success(T data) {
        ApiResponse<T> response = new ApiResponse<>();
        response.success = true;
        response.message = "Success";
        response.data = data;
        return response;
    }

    public static <T> ApiResponse<T> success(
            T data,
            String message
    ) {
        ApiResponse<T> response = new ApiResponse<>();
        response.success = true;
        response.message = message;
        response.data = data;
        return response;
    }
}